Put your Persian font here as: app.ttf (regular) and app-bold.ttf (bold).
Recommended free fonts: Vazirmatn, Estedad, Shabnam.
The app picks them up automatically; no code change needed.
