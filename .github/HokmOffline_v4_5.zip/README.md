# Hokm Online (حکم آفلاین)
1. Create a GitHub repo and upload all files of this folder (keep the `.github` folder).
2. Go to Actions > "Build APK" > Run workflow (it also runs on every push).
3. Download the artifact `HokmOnline-apk` -> app-debug.apk

## v1.1 changes
- Real playing-card images (assets/img/cards/S14.webp = Ace of Spades, H12 = Queen of Hearts ...).
- Deal animation: deck shuffle, 5 cards, trump pick, 8 cards; cards fly to the table; trick sweep.
- New logo/profile image + launcher icons.
- 9 special profiles with animated frames (Shop > Special Profiles), bought with coins.
- Monthly VIP = 1500 coins (editable in Admin).
- Gift codes (Home tile / Shop). Defaults: Newgame, JoJo65, Amir5000, HaJiMMD, Code5000, NewTrack = 1000 coins each.
  Add / edit / disable codes in Admin Panel > Gift codes (coins + optional VIP days), then press Save.

## v3.9 - gifts in hotspot games
- In a hotspot game tap the 🎁 button next to your profile (or tap another player's profile), choose the recipient and a gift, and send it.
- 16 animated gifts (rose, heart, laugh, cry, applause, fire, tea, cake, party, cool, hug, watermelon, blossom, trophy, crown, diamond). Each is bought with coins when sent: 100 coins for most, trophy 200, crown 300, diamond 500.
- The host validates the gift and broadcasts it, so all 4 players see the animation (flying emoji + burst; the receiver also gets a big pop-up). If the host rejects it the coins are refunded.
- Prices are editable in Admin > Gift prices. No change to the Android code (same TCP channel).

## v3.8 - hotspot room settings (host only, inside the room)
- Points to win the match: 1 / 3 / 5 / 7.
- Bam announcement (13-0 after a kot): on = the kot-maker may continue to 13-0; off = a kot is simply 2 points.
- Replace offline players with a bot: on = a player who drops is replaced by a bot at once (game keeps going; he can rejoin and take his seat back); off = game pauses and waits for him (old behaviour).
- Bot level: Beginner / Medium / Master (applies to added bots and replacement bots).
- "Add bot to room" (needs at least 2 real players in the room); bots can be removed with the red X. The game starts when the room is full and all real players (except host) ticked "I'm in".

## v3.7
- Rank tab: new "By level" leaderboard (sorted by level, then trophies).
- Profile frames shop (Shop > Frames): 11 frames bought with coins, 9 animated (Frost, Emerald, Neon, Blaze, Bloodbeat, Lightning, Galaxy, Royal, Diamond). Equip from the shop or Me tab. Frames show in lobby, ranking, game and hotspot rooms. Prices editable in Admin > Frames.
- Season profiles S1-S5 (img/av/s1..s5.webp): permanent, earned by reaching Sultan (top 50) during that season. Shown in Shop > Season profiles.
- Top-50 "Sultan" profile is now timed: rank 11-50 = 7 days, rank 4-10 = 10 days, rank 1-3 = permanent. Moving up a tier extends the time (e.g. 7 -> 10 days). Days editable in Admin (season card). Expired profile is unequipped automatically.
- Login: unselected avatars are less dimmed + hint text.

## v3.6 - Hotspot / Wi-Fi multiplayer (4 players, no internet)
- Home > "بازی با هاتسپات". One player turns on the phone hotspot, the others join that Wi-Fi.
- Host taps "Create room" (shows its address), the other 3 tap "Join room" (address is auto-filled from the hotspot gateway, or type it).
- Lobby holds exactly 4 players. The game starts automatically when all 4 are in and the other 3 tick "I'm in" (وارد بازی می‌شوم).
- Teams: you + the player across from you. Same Hokm rules/animations as the offline game (kot, 13-0, hakem rotation). Host is the referee (phone must stay open).
- If a player drops (network blip / app closed / pressed quit) while the hotspot is still on: the game pauses for everyone, the dropped player auto-reconnects, or sees a "game still running - back to game" message (banner on Home) and returns to the same hand.
- Android: new INTERNET / ACCESS_NETWORK_STATE / ACCESS_WIFI_STATE permissions, TCP port 8765.
- Friendly games: no trophies/coins are changed.

## v3.5
- Card back images moved from a 16KB base64 CSS variable to real files (img/bk.png, img/bkh.png) and pre-decoded.
- Playing a card now patches only the changed DOM (hand, fan, table) instead of re-rendering the whole table; a render error can no longer stall the game.
- Card/table layers are promoted ahead of time. New "⚡ Light mode" tile on Home (removes shadows/animations) as a fallback for weak phones.
- VIP name tag: picking a symbol now turns it on automatically (checkbox can switch it off); old saves with a picked symbol are migrated. Names in game are wider so the tag isn't cut.

## v3.4
- Backup / restore: Home > 💾 (and "Restore" on the login screen). Saves one JSON file in Downloads/HokmOffline, or share it (Telegram, Drive...). After reinstalling, pick the file to get everything back (Android keeps app data only while the app is installed, so the file is what survives uninstall).
- VIP/profile frame animations are back inside the game, now GPU-only (opacity/rotate), VIP name animates in steps. Card/avatar images are pre-decoded.

## v3.3 perf
- Game screen is patched in place (keyed DOM morph) instead of rebuilt on every card; avatar frames/VIP name animations are static inside the game; dim cards use an overlay instead of filter.

## v2.1 changes
- VIP name tag: ♠♣♥♦💎👑🎭⭐✨❄🐦‍🔥 or "VIP" next to the name (Profile > Name tag, opt-in checkbox). Shown in lobby, ranking, waiting room and in game.
- Gold avatar frame is now VIP-only (normal players get a neutral frame; King of Spades special frame is silver).
- New card backs (indigo, real card proportions + border). Dealing is now in packets (5 to each player, then 4+4) with an arc flight; opponents' hands are drawn as small fans.
- New scoreboard: team avatars, big scores, 7 trick pips per team and a diamond trump medallion (no more "us/them" text).
- Bots play each other every N seconds (default 10 s, 3 matches per round, +/-20 trophies, zero-sum). Catches up while the app was closed.
- New rank system: 10 ranks x 3 tiers (3 -> 1, 1 = best) with SVG badges + "Sultan" for the top 50 (unlocks the special Top-50 profile).
- Seasons (default 7 days). Reaching the set rank (default Diamond) gives an S1/S2/... badge on the profile. Season end = coin reward + soft trophy reset (default keep 75%).
- New profile page: level ring, rank progress, name tag, 12 stats, season badges, achievements, rank road, recent matches.
- Admin Panel: bot battles (on/off, interval, matches per round, trophy delta), season settings (length, reset %, badge rank, end season now), bot management with search by name/ID (edit name, avatar, level, trophies, games, wins, AI, VIP + tag, reset to default).

## v4.0
- 25 new gift codes (1000 coins each, prefix HK...). Visible/editable in Admin > Gift codes; existing installs get them added automatically (custom codes kept). New "Copy all codes" button in Admin.
- 12 new decorative emoji frames (hearts, pink hearts, card suits, stars, shining stars, blossom, clover, moon & stars, butterflies, rainbow, crown, gems) - an emoji ring around the avatar + animated colored ring. Prices editable in Admin > Frames.
- Bot names: realistic "First Last" names (e.g. Reza Ahmadi / رضا احمدی), gamer nicknames, and first name + birth year; unique across all bots. Bot stats are unchanged.
