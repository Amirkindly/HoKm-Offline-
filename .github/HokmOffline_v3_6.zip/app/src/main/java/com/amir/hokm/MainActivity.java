package com.amir.hokm;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.WindowManager;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;
import android.content.Context;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private static final int REQ_PICK = 7;
    private WebView web;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#12031f"));
        getWindow().setNavigationBarColor(Color.parseColor("#12031f"));
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#0c0214"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(), "HokmNative");
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }


    /* ================= Local network (hotspot / Wi-Fi) multiplayer ================= */
    private static final java.nio.charset.Charset U8 = java.nio.charset.Charset.forName("UTF-8");

    private class Conn {
        final Socket s; final int id;
        final ExecutorService ex = Executors.newSingleThreadExecutor();
        final OutputStream out;
        Conn(Socket s, int id) throws java.io.IOException { this.s = s; this.id = id; this.out = s.getOutputStream(); }
        void send(final String line) {
            try {
                ex.execute(new Runnable() { public void run() {
                    try { out.write((line + "\n").getBytes(U8)); out.flush(); } catch (Exception e) { close(); }
                } });
            } catch (Exception ignored) { }
        }
        void close() { try { s.close(); } catch (Exception ignored) { } try { ex.shutdown(); } catch (Exception ignored) { } }
    }

    private ServerSocket srv;
    private final Map<Integer, Conn> hostConns = new ConcurrentHashMap<Integer, Conn>();
    private int nextId = 1;
    private Conn cli;
    private volatile int curGen = -1;

    private void emit(String type, int id, String data) {
        final String js = "window.mpNative&&window.mpNative(" + JSONObject.quote(type) + "," + id + "," + JSONObject.quote(data == null ? "" : data) + ")";
        web.post(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
    }

    private void hostReader(final Conn cn) {
        Thread t = new Thread(new Runnable() { public void run() {
            try {
                BufferedReader r = new BufferedReader(new InputStreamReader(cn.s.getInputStream(), U8));
                String l;
                while ((l = r.readLine()) != null) {
                    if (l.length() > 65536) break;
                    emit("hm", cn.id, l);
                }
            } catch (Exception ignored) { }
            cn.close();
            if (hostConns.remove(cn.id) != null) emit("hx", cn.id, "");
        } });
        t.setDaemon(true); t.start();
    }

    private void stopHost() {
        try { if (srv != null) srv.close(); } catch (Exception ignored) { }
        srv = null;
        List<Conn> l = new ArrayList<Conn>(hostConns.values());
        hostConns.clear();
        for (Conn c : l) c.close();
    }

    private String ipv4(int g) { return (g & 0xff) + "." + ((g >> 8) & 0xff) + "." + ((g >> 16) & 0xff) + "." + ((g >> 24) & 0xff); }

    /** Backup helpers called from JS (window.HokmNative). */
    private class Bridge {

        /* ---- host side ---- */
        @JavascriptInterface
        public String hostStart(int port) {
            stopHost();
            try {
                final ServerSocket ss = new ServerSocket();
                ss.setReuseAddress(true);
                ss.bind(new InetSocketAddress(port));
                srv = ss;
                Thread t = new Thread(new Runnable() { public void run() {
                    while (!ss.isClosed()) {
                        try {
                            Socket c = ss.accept();
                            c.setTcpNoDelay(true); c.setKeepAlive(true);
                            Conn cn = new Conn(c, nextId++);
                            hostConns.put(cn.id, cn);
                            emit("hc", cn.id, "");
                            hostReader(cn);
                        } catch (Exception e) { if (ss.isClosed()) break; }
                    }
                } });
                t.setDaemon(true); t.start();
                return "";
            } catch (Exception e) { return String.valueOf(e.getMessage()); }
        }

        @JavascriptInterface public void hostStop() { stopHost(); }

        @JavascriptInterface public void hostSend(int id, String line) {
            Conn c = hostConns.get(id); if (c != null) c.send(line);
        }

        @JavascriptInterface public void hostKick(int id) {
            Conn c = hostConns.remove(id); if (c != null) c.close();
        }

        /* ---- client side ---- */
        @JavascriptInterface
        public void connect(final String ip, final int port, final int gen) {
            disconnect();
            curGen = gen;
            Thread t = new Thread(new Runnable() { public void run() {
                Socket s = null;
                try {
                    s = new Socket();
                    s.connect(new InetSocketAddress(ip, port), 3500);
                    s.setTcpNoDelay(true); s.setKeepAlive(true);
                } catch (Exception e) {
                    try { if (s != null) s.close(); } catch (Exception ignored) { }
                    if (curGen == gen) emit("ce", gen, String.valueOf(e.getMessage()));
                    return;
                }
                final Conn cn;
                try { cn = new Conn(s, gen); } catch (Exception e) { if (curGen == gen) emit("ce", gen, "io"); return; }
                if (curGen != gen) { cn.close(); return; }
                cli = cn;
                emit("co", gen, "");
                try {
                    BufferedReader r = new BufferedReader(new InputStreamReader(s.getInputStream(), U8));
                    String l;
                    while ((l = r.readLine()) != null) {
                        if (l.length() > 65536) break;
                        if (curGen != gen) break;
                        emit("cm", gen, l);
                    }
                } catch (Exception ignored) { }
                cn.close();
                if (curGen == gen) emit("cx", gen, "");
            } });
            t.setDaemon(true); t.start();
        }

        @JavascriptInterface public void send(String line) { Conn c = cli; if (c != null) c.send(line); }

        @JavascriptInterface public void disconnect() {
            curGen = -1;
            Conn c = cli; cli = null;
            if (c != null) c.close();
        }

        /* ---- helpers ---- */
        /** {"ips":[...this phone's LAN/hotspot addresses...],"gw":"gateway when joined to someone's hotspot"} */
        @JavascriptInterface
        public String info() {
            JSONObject o = new JSONObject();
            try {
                List<String> pri = new ArrayList<String>(), sec = new ArrayList<String>();
                Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces();
                while (en != null && en.hasMoreElements()) {
                    NetworkInterface ni = en.nextElement();
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    String nm = ni.getName().toLowerCase();
                    if (nm.startsWith("rmnet") || nm.startsWith("ccmni") || nm.startsWith("tun") || nm.startsWith("dummy") || nm.startsWith("v4-") || nm.startsWith("clat")) continue;
                    for (InetAddress ia : Collections.list(ni.getInetAddresses())) {
                        if (ia instanceof Inet4Address && !ia.isLoopbackAddress() && ia.isSiteLocalAddress()) {
                            if (nm.startsWith("wlan") || nm.startsWith("ap") || nm.startsWith("swlan")) pri.add(ia.getHostAddress());
                            else sec.add(ia.getHostAddress());
                        }
                    }
                }
                pri.addAll(sec);
                o.put("ips", new JSONArray(pri));
                String gw = "";
                try {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    int g = wm.getDhcpInfo().gateway;
                    if (g != 0) gw = ipv4(g);
                } catch (Exception ignored) { }
                o.put("gw", gw);
            } catch (Exception ignored) { }
            return o.toString();
        }

        @JavascriptInterface
        public void keepOn(final boolean on) {
            runOnUiThread(new Runnable() { public void run() {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            } });
        }

        @JavascriptInterface
        public void openSettings() {
            runOnUiThread(new Runnable() { public void run() {
                try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } catch (Exception ignored) { }
            } });
        }
        /** Writes the backup into Downloads/HokmOffline. Returns a readable path, or "" on failure. */
        @JavascriptInterface
        public String save(String name, String data) {
            if (Build.VERSION.SDK_INT < 29) return ""; // old phones: JS tells the user to use "Send"
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                v.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HokmOffline");
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (u == null) return "";
                try (OutputStream o = getContentResolver().openOutputStream(u)) {
                    if (o == null) return "";
                    o.write(data.getBytes("UTF-8"));
                }
                return "Download/HokmOffline/" + name;
            } catch (Exception e) {
                return "";
            }
        }

        /** Opens the share sheet with the backup text (Telegram saved messages, Drive, email...). */
        @JavascriptInterface
        public void share(final String name, final String data) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_SEND);
                        i.setType("text/plain");
                        i.putExtra(Intent.EXTRA_SUBJECT, name);
                        i.putExtra(Intent.EXTRA_TEXT, data);
                        startActivity(Intent.createChooser(i, name));
                    } catch (Exception ignored) { }
                }
            });
        }

        /** Opens the system file picker to choose a backup file. */
        @JavascriptInterface
        public void pick() {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("*/*");
                        startActivityForResult(i, REQ_PICK);
                    } catch (Exception ignored) { }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_PICK || res != RESULT_OK || data == null || data.getData() == null) return;
        try (InputStream in = getContentResolver().openInputStream(data.getData())) {
            if (in == null) return;
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n, total = 0;
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > 8 * 1024 * 1024) return; // not a backup
                bo.write(buf, 0, n);
            }
            final String js = "window.onBackupPicked&&window.onBackupPicked(" + JSONObject.quote(bo.toString("UTF-8")) + ")";
            web.post(new Runnable() { public void run() { web.evaluateJavascript(js, null); } });
        } catch (Exception ignored) { }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.mpResume&&mpResume()", null);
    }

    @Override
    protected void onDestroy() {
        stopHost();
        curGen = -1;
        Conn c = cli; cli = null;
        if (c != null) c.close();
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean f) {
        super.onWindowFocusChanged(f);
        if (f) getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.goBack&&window.goBack()", v -> {
            if (v == null || !v.contains("1")) finish();
        });
    }
}
