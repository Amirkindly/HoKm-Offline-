# Hokm Online (حکم آفلاین)
1. Create a GitHub repo and upload all files of this folder (keep the `.github` folder).
2. Go to Actions > "Build APK" > Run workflow (it also runs on every push).
3. Download the artifact `HokmOnline-apk` -> app-debug.apk

## v1.1 changes
- Real playing-card images (assets/img/cards/S14.webp = Ace of Spades, H12 = Queen of Hearts ...).
- Deal animation: deck shuffle, 5 cards, trump pick, 8 cards; cards fly to the table; trick sweep.
- New logo/profile image + launcher icons.
- 9 special profiles with animated frames (Shop > Special Profiles), bought with coins.
- Monthly VIP = 1500 coins (editable in Admin).
- Gift codes (Home tile / Shop). Defaults: Newgame, JoJo65, Amir5000, HaJiMMD, Code5000, NewTrack = 1000 coins each.
  Add / edit / disable codes in Admin Panel > Gift codes (coins + optional VIP days), then press Save.

## v3.4
- Backup / restore: Home > 💾 (and "Restore" on the login screen). Saves one JSON file in Downloads/HokmOffline, or share it (Telegram, Drive...). After reinstalling, pick the file to get everything back (Android keeps app data only while the app is installed, so the file is what survives uninstall).
- VIP/profile frame animations are back inside the game, now GPU-only (opacity/rotate), VIP name animates in steps. Card/avatar images are pre-decoded.

## v3.3 perf
- Game screen is patched in place (keyed DOM morph) instead of rebuilt on every card; avatar frames/VIP name animations are static inside the game; dim cards use an overlay instead of filter.

## v2.1 changes
- VIP name tag: ♠♣♥♦💎👑🎭⭐✨❄🐦‍🔥 or "VIP" next to the name (Profile > Name tag, opt-in checkbox). Shown in lobby, ranking, waiting room and in game.
- Gold avatar frame is now VIP-only (normal players get a neutral frame; King of Spades special frame is silver).
- New card backs (indigo, real card proportions + border). Dealing is now in packets (5 to each player, then 4+4) with an arc flight; opponents' hands are drawn as small fans.
- New scoreboard: team avatars, big scores, 7 trick pips per team and a diamond trump medallion (no more "us/them" text).
- Bots play each other every N seconds (default 10 s, 3 matches per round, +/-20 trophies, zero-sum). Catches up while the app was closed.
- New rank system: 10 ranks x 3 tiers (3 -> 1, 1 = best) with SVG badges + "Sultan" for the top 50 (unlocks the special Top-50 profile).
- Seasons (default 7 days). Reaching the set rank (default Diamond) gives an S1/S2/... badge on the profile. Season end = coin reward + soft trophy reset (default keep 75%).
- New profile page: level ring, rank progress, name tag, 12 stats, season badges, achievements, rank road, recent matches.
- Admin Panel: bot battles (on/off, interval, matches per round, trophy delta), season settings (length, reset %, badge rank, end season now), bot management with search by name/ID (edit name, avatar, level, trophies, games, wins, AI, VIP + tag, reset to default).
