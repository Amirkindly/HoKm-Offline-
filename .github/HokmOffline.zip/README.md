# Hokm Online (حکم آفلاین)
1. Create a GitHub repo and upload all files of this folder (keep the `.github` folder).
2. Go to Actions > "Build APK" > Run workflow (it also runs on every push).
3. Download the artifact `HokmOnline-apk` -> app-debug.apk
